import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    exclude: ["tests/integration/**"],
    sequence: { shuffle: false },
    fileParallelism: false,
    pool: "threads",
    isolate: true,
  },
});
